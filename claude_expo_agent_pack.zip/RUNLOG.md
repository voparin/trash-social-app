# RUNLOG

Append one entry per agent run.

Template:
- Date:
- Agent:
- Task ID:
- Summary:
- Files changed:
- Commands run:
- Verification result:
- Follow-ups / bugs:
